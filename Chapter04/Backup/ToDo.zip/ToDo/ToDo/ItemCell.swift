//
//  ItemCell.swift
//  ToDo
//
//  Created by CoderDream on 2019/9/18.
//  Copyright © 2019 CoderDream. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {
    
    
    //let titleLabel = UILabel()
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var locationLabel: UILabel!
    
    func configCell(with item: ToDoItem) {
    }
}
