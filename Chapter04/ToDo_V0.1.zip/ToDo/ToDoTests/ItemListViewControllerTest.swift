//
//  ItemListViewControllerTest.swift
//  ToDoTests
//
//  Created by CoderDream on 2019/9/20.
//  Copyright © 2019 CoderDream. All rights reserved.
//

import XCTest
@testable import ToDo

class ItemListViewControllerTest: XCTestCase {

    override func setUp() {
    }

    override func tearDown() {
    }
    
//    func test_TableViewIsNotNilAfterViewDidLoad() {
//        let sut = ItemListViewController()
//        sut.loadViewIfNeeded()
//        XCTAssertNotNil(sut.tableView)
//    }
//
//    func test_TableView_AfterViewDidLoad_IsNotNil() {
//        let storyboard = UIStoryboard(name: "Main",
//                                      bundle: nil)
//        let viewController =
//            storyboard.instantiateViewController(
//                withIdentifier: "ItemListViewController")
//        let sut = viewController
//            as! ItemListViewController
//        sut.loadViewIfNeeded()
//        XCTAssertNotNil(sut.tableView)
//    }

    func test_LoadingView_SetsTableViewDataSource() {
        let storyboard = UIStoryboard(name: "Main",
                                      bundle: nil)
        let viewController =
            storyboard.instantiateViewController(
                withIdentifier: "ItemListViewController")
        let sut = viewController
            as! ItemListViewController
        sut.loadViewIfNeeded()
        XCTAssertTrue(sut.tableView.dataSource is ItemListDataProvider)
    }

}
